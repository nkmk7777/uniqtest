import re
import os

from aiogram import Router
from aiogram.filters import CommandStart, Command, StateFilter
from aiogram.types import Message, FSInputFile
from aiogram.enums.content_type import ContentType
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext

from tgbot.filters.admin import AdminFilter
from tgbot.services.broadcaster import broadcast
from infrastructure.database.repo.requests import create_user, get_user, get_active_users, get_user_by_username, update_user, get_all_users, user_is_registered
from tgbot.misc.states import Mailing, AdminStGroup
from .utilities import check_user_folder, save_file

admin_router = Router()
admin_router.message.filter(AdminFilter())


@admin_router.message(StateFilter(None), Command("admin"))
async def admin_start(message: Message, state: FSMContext):
    await state.set_state(AdminStGroup.on)
    await message.answer(
        "<b>Добро пожаловать в админ панель!</b>\n"
        "Список доступных команд:\n\n"
        "<code>/stats</code> - Показать статистику активных пользователей за 24ч\n"
        "<code>/ban @username</code> - Заблокировать пользователя\n"
        "<code>/unban @username</code> - Разблокировать пользователя\n"
        "<code>/mailing</code> - Начать рассылку\n"
    )


@admin_router.message(StateFilter(AdminStGroup.on, Mailing.get_text), Command("exit"))
async def admin_start(message: Message, state: FSMContext):
    current_state = await state.get_state()
    if current_state.split(":")[1] == "on":
        await state.clear()
        await message.answer("Вы вышли из админ панели.")
    else:
        await state.set_state(AdminStGroup.on)
        await message.answer("Вы закончили рассылку.")


@admin_router.message(StateFilter(AdminStGroup.on), CommandStart())
async def admin_start(message: Message, state: FSMContext):
    await message.answer(
        "<b>Добро пожаловать в админ панель!</b>\n"
        "Список доступных команд:\n\n"
        "<code>/stats</code> - Показать статистику активных пользователей за 24ч\n"
        "<code>/ban @username</code> - Заблокировать пользователя\n"
        "<code>/unban @username</code> - Разблокировать пользователя\n"
        "<code>/mailing</code> - Начать рассылку\n"
    )


@admin_router.message(StateFilter(None), CommandStart())
async def admin_start(message: Message, state: FSMContext):
    check_user = await user_is_registered(message.from_user.id)
    if not check_user:
        await create_user(
            message.from_user.id,
            message.from_user.full_name,
            message.from_user.username
        )
    check_user_folder(message.from_user.username, os.getcwd())
    await message.answer(
        "<b>🎥 Уникализатор Медиа ⚙️</b>"
        + "\n\n📌 Этот бот был создан специально для уникализации креативов для Facebook/Google/YouTube."
        + "\n\n🤔 Что умеет этот бот:"
        + "\n\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Накладывает невидимые элементы на видео."
        + "\n✅ Удаляет метаданные."
        + "\n\n👍 99% захода креативов!!!",
        parse_mode=ParseMode.HTML,
    )
    await message.answer(
        "<b>⚠️ Отправьте боту видео или фото до 20МБ или с меньшим разрешением!\n\n"
        + "Если нужно отправить видео-файл больше 20МБ, загрузите его на файлообменник pixeldrain.com и отправьте ссылку на файл боту.</b>",
        parse_mode=ParseMode.HTML
    )


@admin_router.message(StateFilter(AdminStGroup.on), Command("stats"))
async def admin_stats(message: Message):
    users = await get_active_users()
    text = "<b>Статистика активных пользователей за 24ч:</b>\n\n"
    for user in users:
        text = text + f"@{user.username} - <code>{user.last_activity}</code>\n"
    await message.answer(text, parse_mode=ParseMode.HTML)


@admin_router.message(StateFilter(AdminStGroup.on), Command("ban"))
async def admin_ban(message: Message):
    match = re.match(r'^/ban\s+@?(\w+)$', message.text)
    if match:
        username = match.group(1)
        user = await get_user_by_username(username)
        if user.banned:
            await message.reply(f"Пользователь @{username} уже заблокирован!")
        elif user:
            await update_user(user.user_id, banned=True)
            await message.reply(f"Пользователь @{username} заблокирован!")
        else:
            await message.reply(f"Пользователь @{username} не найден!")
    else:
        await message.reply("Введите <code>/ban @username</code>", parse_mode=ParseMode.HTML)


@admin_router.message(StateFilter(AdminStGroup.on), Command("unban"))
async def admin_unban(message: Message):
    match = re.match(r'^/unban\s+@?(\w+)$', message.text)
    if match:
        username = match.group(1)
        user = await get_user_by_username(username)
        if not user.banned:
            await message.reply(f"Пользователь @{username} уже разблокирован!")
        elif user:
            await update_user(user.user_id, banned=False)
            await message.reply(f"Пользователь @{username} разблокирован!")
        else:
            await message.reply(f"Пользователь @{username} не найден!")
    else:
        await message.reply("Введите <code>/unban @username</code>", parse_mode=ParseMode.HTML)


@admin_router.message(StateFilter(AdminStGroup.on), Command("mailing"))
async def admin_mailing(message: Message, state: FSMContext):
    await message.answer("⚠️ Отправьте боту текст рассылки до 2000 символов!")
    await state.set_state(Mailing.get_text)


@admin_router.message(StateFilter(Mailing.get_text))
async def admin_mailing2(message: Message, state: FSMContext):
    text = message.text if message.text is not None else message.caption
    if text:
        if len(text) > 2000:
            await message.answer("⚠️ Текст рассылки не должен превышать 2000 символов!")
            return

    current_dir = os.getcwd()
    users = await get_all_users()
    # сount = await broadcast(
    #     message._bot,
    #     [user.user_id for user in users],
    #     text
    # )
    count = 0
    for user in users:
        count += 1
        if message.content_type == ContentType.DOCUMENT:
            file_id = message.document.file_id
            file_name = message.document.file_name
            file_size = message.document.file_size
            if file_size > 20 * 1024 * 1024:
                await message.reply("⚠️ Файл больше 20МБ!")
                await message.answer("Попробуйте меньше файл")
                return
            file = await message._bot.get_file(file_id)
            file_path = file.file_path
            file_name = f"mailing_{file_name}"
            await save_file(message._bot, file_path, f"files/{message.from_user.username}", file_name)
            
            input_src = f"{current_dir}/files/{message.from_user.username}/{file_name}"
            await message._bot.send_document(
                user.user_id,
                document=FSInputFile(input_src),
                caption=text
            )
            os.remove(input_src)

        elif message.content_type == ContentType.VIDEO:
            file_id = message.video.file_id
            file_name = message.video.file_unique_id
            file_size = message.video.file_size
            if file_size > 20 * 1024 * 1024:
                await message.reply("⚠️ Файл больше 20МБ!")
                await message.answer("Попробуйте меньше файл")
                return
            file = await message._bot.get_file(file_id)
            file_path = file.file_path
            file_name = f"mailing_{file_name}"
            await save_file(message._bot, file_path, f"files/{message.from_user.username}", file_name)
            
            input_src = f"{current_dir}/files/{message.from_user.username}/{file_name}"
            
            await message._bot.send_video(
                user.user_id,
                video=FSInputFile(input_src),
                caption=text
            )
            os.remove(input_src)

        elif message.content_type == ContentType.PHOTO:
            photo = message.photo[-1]
            file_id = photo.file_id
            file_name = photo.file_unique_id
            file_size = photo.file_size
            if file_size > 20 * 1024 * 1024:
                await message.reply("⚠️ Файл больше 20МБ!")
                await message.answer("Попробуйте меньше файл")
                return
            file = await message._bot.get_file(file_id)
            file_path = file.file_path
            file_name = f"mailing_{file_name}"
            await save_file(message._bot, file_path, f"files/{message.from_user.username}", file_name)
            
            input_src = f"{current_dir}/files/{message.from_user.username}/{file_name}"

            await message._bot.send_photo(
                user.user_id,
                photo=FSInputFile(input_src),
                caption=text
            )
            os.remove(input_src)

        elif message.content_type == ContentType.STICKER:
            await message._bot.send_sticker(
                user.user_id,
                sticker=message.sticker.file_id,
                emoji=message.sticker.emoji
            )
        
        elif message.content_type == ContentType.TEXT:
            await message._bot.send_message(
                user.user_id,
                text=text
            )
        
        # await message.bot.send_message(user.user_id, text, parse_mode=ParseMode.HTML)
    await message.answer(
        f"<b>✅ Рассылка завершена!</b>\n\n"
        + f"Колличество пользователей: <code>{len(users)}</code>\n"
        + f"Колличество отправленных сообщений: <code>{count}</code>\n"
    )
    await state.set_state(AdminStGroup.on)